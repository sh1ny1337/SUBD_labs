CREATE TABLE `Person` (
	`ID_Person` int NOT NULL AUTO_INCREMENT,
	`Surname` char(20) NOT NULL,
	`Name` char(20) NOT NULL,
	`Father_Name` char(20) NOT NULL,
	`Birthday` DATE NOT NULL,
	PRIMARY KEY (`ID_Person`)
);

CREATE TABLE `Car` (
	`ID_Car` int NOT NULL AUTO_INCREMENT,
	`ID_Driver` int NOT NULL,
	`Brand` char(20) NOT NULL,
	`Model` char(20) NOT NULL,
	`Car_Number` char(10) NOT NULL,
	`Load_Capacity(kg)` int(10) NOT NULL,
	PRIMARY KEY (`ID_Car`)
);

CREATE TABLE `Driver` (
	`ID_Driver` int NOT NULL AUTO_INCREMENT,
	`ID_Person` int NOT NULL,
	`Start_Work_Day` DATE NOT NULL,
	`Count_Order` int NOT NULL,
	`Salary` int NOT NULL,
	PRIMARY KEY (`ID_Driver`)
);

CREATE TABLE `Customer` (
	`ID_Customer` int NOT NULL AUTO_INCREMENT,
	`ID_Person` int NOT NULL,
	`Count_Order` int NOT NULL,
	`Discount` int NOT NULL,
	PRIMARY KEY (`ID_Customer`)
);

CREATE TABLE `Destinations` (
	`ID_Destinations` int NOT NULL AUTO_INCREMENT,
	`Name` char(20) NOT NULL,
	`CoordsX` char(20) NOT NULL,
	`CoordsY` char(20) NOT NULL,
	PRIMARY KEY (`ID_Destinations`)
);

CREATE TABLE `Order` (
	`ID_Order` int NOT NULL AUTO_INCREMENT,
	`Name` char(20) NOT NULL,
	`Weight(kg)` int NOT NULL,
	`ID_Destination_Start` int NOT NULL,
	`ID_Destination_End` int NOT NULL,
	`Date_Start` DATE NOT NULL,
	`Date_End` DATE NOT NULL,
	`Price` int NOT NULL,
	PRIMARY KEY (`ID_Order`)
);

CREATE TABLE `Contract` (
	`ID_Contract` int NOT NULL AUTO_INCREMENT,
	`ID_Order` int NOT NULL,
	`ID_Car` int NOT NULL,
	`ID_Customer` int NOT NULL,
	`Description` char(100) NOT NULL,
	PRIMARY KEY (`ID_Contract`)
);

ALTER TABLE `Car` ADD CONSTRAINT `Car_fk0` FOREIGN KEY (`ID_Driver`) REFERENCES `Driver`(`ID_Driver`);

ALTER TABLE `Driver` ADD CONSTRAINT `Driver_fk0` FOREIGN KEY (`ID_Person`) REFERENCES `Person`(`ID_Person`);

ALTER TABLE `Customer` ADD CONSTRAINT `Customer_fk0` FOREIGN KEY (`ID_Person`) REFERENCES `Person`(`ID_Person`);

ALTER TABLE `Order` ADD CONSTRAINT `Order_fk0` FOREIGN KEY (`ID_Destination_Start`) REFERENCES `Destinations`(`ID_Destinations`);

ALTER TABLE `Order` ADD CONSTRAINT `Order_fk1` FOREIGN KEY (`ID_Destination_End`) REFERENCES `Destinations`(`ID_Destinations`);

ALTER TABLE `Contract` ADD CONSTRAINT `Contract_fk0` FOREIGN KEY (`ID_Order`) REFERENCES `Order`(`ID_Order`);

ALTER TABLE `Contract` ADD CONSTRAINT `Contract_fk1` FOREIGN KEY (`ID_Car`) REFERENCES `Car`(`ID_Car`);

ALTER TABLE `Contract` ADD CONSTRAINT `Contract_fk2` FOREIGN KEY (`ID_Customer`) REFERENCES `Customer`(`ID_Customer`);

